import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# -----------------------------
# Load datasets
# -----------------------------
hdi = pd.read_csv("Dataset/human-development-index.csv")
expected = pd.read_csv("Dataset/expected-years-of-schooling.csv")
mean = pd.read_csv("Dataset/mean-years-of-schooling-long-run.csv")
gni = pd.read_csv("Dataset/gross-national-income-per-capita.csv")

# -----------------------------
# Merge datasets
# -----------------------------
data = hdi.merge(expected, on=["Entity", "Code", "Year"])
data = data.merge(mean, on=["Entity", "Code", "Year"])
data = data.merge(gni, on=["Entity", "Code", "Year"])

# -----------------------------
# Remove missing values
# -----------------------------
data.dropna(inplace=True)

print("Dataset Shape:", data.shape)
print(data.head())

# -----------------------------
# Independent and Dependent Variables
# -----------------------------
X = data[
    [
        "Expected Years of Schooling (years)",
        "Average Total Years of Schooling for Adult Population (Lee-Lee (2016), Barro-Lee (2018) and UNDP (2018))",
        "GNI per capita, PPP (constant 2017 international $)"
    ]
]

y = data["Human Development Index (UNDP)"]

# -----------------------------
# Train Test Split
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# -----------------------------
# Train Linear Regression Model
# -----------------------------
model = LinearRegression()

model.fit(X_train, y_train)

# -----------------------------
# Prediction
# -----------------------------
y_pred = model.predict(X_test)

# -----------------------------
# Evaluation
# -----------------------------
print("\nModel Evaluation")
print("-------------------------")
print("MAE :", mean_absolute_error(y_test, y_pred))
print("MSE :", mean_squared_error(y_test, y_pred))
print("RMSE:", mean_squared_error(y_test, y_pred) ** 0.5)
print("R2 Score:", r2_score(y_test, y_pred))

# -----------------------------
# Save Model
# -----------------------------
with open("model/linear_regression_model.pkl", "wb") as file:
    pickle.dump(model, file)

print("\nModel Saved Successfully!")