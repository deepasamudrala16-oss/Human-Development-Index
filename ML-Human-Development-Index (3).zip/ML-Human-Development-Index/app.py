from flask import Flask, render_template, request
import pickle
import numpy as np

# Create Flask App
app = Flask(__name__)

# Load Trained Model
model = pickle.load(open("model/linear_regression_model.pkl", "rb"))


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    try:
        expected_schooling = float(request.form["expected_schooling"])
        mean_schooling = float(request.form["mean_schooling"])
        gni = float(request.form["gni"])

        prediction = model.predict(np.array([[expected_schooling,
                                              mean_schooling,
                                              gni]]))

        result = round(prediction[0], 4)

        return render_template(
            "result.html",
            prediction=result
        )

    except Exception as e:
        return render_template(
            "result.html",
            prediction=f"Error: {str(e)}"
        )


if __name__ == "__main__":
    app.run(debug=True)