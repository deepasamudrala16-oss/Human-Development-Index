# Human Development Index Prediction Using Linear Regression

## Project Overview

This project predicts the Human Development Index (HDI) using a Linear Regression model built with Scikit-learn and deployed using Flask.

---

## Technologies Used

- Python
- Pandas
- NumPy
- Scikit-learn
- Flask
- HTML
- CSS

---

## Project Structure

```
Project/
│
├── app.py
├── train_model.py
├── requirements.txt
│
├── Dataset/
│
├── model/
│
├── templates/
│   ├── index.html
│   └── result.html
│
├── static/
│   └── style.css
```

---

## Install Required Packages

```bash
pip install -r requirements.txt
```

---

## Train the Model

```bash
python train_model.py
```

---

## Run the Flask Application

```bash
python app.py
```

---

## Open Browser

```
http://127.0.0.1:5000/
```

---

## Output

Enter:

- Expected Years of Schooling
- Mean Years of Schooling
- Gross National Income Per Capita

Click **Predict HDI** to view the predicted Human Development Index.

---

## Author

Human Development Index Prediction using Linear Regression and Flask.